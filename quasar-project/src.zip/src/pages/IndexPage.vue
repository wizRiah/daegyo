<template>
  <q-page class="flex flex-center">
    <!-- <img alt="hunjang logo" src="~assets/hunjang_logo.png"> -->
  </q-page>
</template>

<script setup></script>
